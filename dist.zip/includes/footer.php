    </main>
    <footer class="bg-gray-800 text-white text-center p-4 mt-8">
        <p>&copy; 2025 BraniFrequentiWakeWorship</p>
    </footer>
    <script src="js/scripts.js"></script>
</body>
</html>